// ===== الإعدادات: غيّر هذا الرابط إذا السيرفر مالك على جهاز ثاني =====
const API_URL = "http://localhost:11434"; // الـ API الخاص بيك (Ollama)
const SYSTEM_PROMPT = "انت مساعد ذكي ومفيد. جاوب بنفس لغة المستخدم.";
// ==================================================================

const $ = (id) => document.getElementById(id);
let history = [];

function add(text, cls) {
  const empty = $("empty");
  if (empty) empty.remove();
  const d = document.createElement("div");
  d.className = "msg " + cls;
  d.textContent = text;
  $("chat").appendChild(d);
  $("chat").scrollTop = 1e9;
  return d;
}

// يجيب الموديلات المثبتة عندك
async function loadModels() {
  try {
    const r = await fetch(API_URL + "/api/tags");
    const j = await r.json();
    $("model").innerHTML = "";
    j.models.forEach((m) => {
      const o = document.createElement("option");
      o.value = o.textContent = m.name;
      $("model").appendChild(o);
    });
    $("status").textContent = j.models.length ? "🟢 متصل" : "ما كو موديل مثبت";
  } catch (e) {
    $("status").textContent = "🔴 السيرفر مطفي";
  }
}

// يرسل الرسالة ويستقبل الرد كلمة كلمة
async function ask(botEl) {
  const r = await fetch(API_URL + "/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: $("model").value,
      stream: true,
      messages: [{ role: "system", content: SYSTEM_PROMPT }, ...history],
    }),
  });
  if (!r.ok) throw new Error("خطأ من السيرفر: " + r.status);

  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = "", full = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop();
    for (const line of lines) {
      if (!line.trim()) continue;
      const j = JSON.parse(line);
      if (j.message) {
        full += j.message.content;
        botEl.textContent = full;
        $("chat").scrollTop = 1e9;
      }
    }
  }
  return full;
}

$("form").onsubmit = async (e) => {
  e.preventDefault();
  const text = $("input").value.trim();
  if (!text) return;
  $("input").value = "";
  add(text, "user");
  history.push({ role: "user", content: text });
  const bot = add("...", "bot");
  $("send").disabled = true;
  try {
    const answer = await ask(bot);
    history.push({ role: "assistant", content: answer });
  } catch (err) {
    bot.textContent = "⚠️ " + err.message + " — تأكد السيرفر شغال (شوف README)";
    bot.classList.add("err");
    history.pop();
  }
  $("send").disabled = false;
};

$("input").onkeydown = (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    $("form").requestSubmit();
  }
};

$("clear").onclick = () => {
  history = [];
  $("chat").innerHTML = '<div id="empty" class="empty">محادثة جديدة 👇</div>';
};

loadModels();
